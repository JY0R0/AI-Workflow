from pdfminer.high_level import extract_text
import requests

def pdf_to_text(file_path):
    return extract_text(file_path)

def extract_experience(text):
    prompt = f"""
Extract the following structured data from this resume:

Name
Company 1, Title 1, Start Date 1, End Date 1
Company 2, Title 2, Start Date 2, End Date 2
Company 3, Title 3, Start Date 3, End Date 3

If some fields are missing, leave them blank. Respond in JSON format.

Resume:
{text}
"""
    response = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": "llama3",
            "prompt": prompt,
            "stream": False
        }
    )
    result = response.json()["response"]
    return result