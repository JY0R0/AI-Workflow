from drive import authenticate_drive, list_pdfs_from_folder, download_pdf
from sheets import authenticate_sheets, insert_into_sheet
from parser import pdf_to_text, extract_experience
import json

def main(folder_id, sheet_id):
    drive_service = authenticate_drive()
    sheet_service = authenticate_sheets()

    files = list_pdfs_from_folder(drive_service, folder_id)
    for file in files:
        print(f"Processing {file['name']}...")
        pdf_path = f"./{file['name']}"
        download_pdf(drive_service, file['id'], pdf_path)
        text = pdf_to_text(pdf_path)

        response = extract_experience(text)

        try:
            data = json.loads(response)
            row = [
                data.get("Name", ""),
                data.get("Company 1", ""), data.get("Title 1", ""), data.get("Start Date 1", ""), data.get("End Date 1", ""),
                data.get("Company 2", ""), data.get("Title 2", ""), data.get("Start Date 2", ""), data.get("End Date 2", ""),
                data.get("Company 3", ""), data.get("Title 3", ""), data.get("Start Date 3", ""), data.get("End Date 3", "")
            ]
            insert_into_sheet(sheet_service, sheet_id, row)
        except Exception as e:
            print("Error parsing or inserting data:", e)

if __name__ == "__main__":
    FOLDER_ID = "your_drive_folder_id"
    SHEET_ID = "your_google_sheet_id"
    main(FOLDER_ID, SHEET_ID)